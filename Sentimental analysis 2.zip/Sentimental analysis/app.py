from flask import Flask, render_template, request
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import nltk

nltk.download('vader_lexicon')

app = Flask(__name__)

@app.route('/', methods=["GET", "POST"])
def main():
    if request.method == "POST":
        inp = request.form.get("inp")
        sid = SentimentIntensityAnalyzer()
        score = sid.polarity_scores(inp)
        
        if score["compound"] >= 0.05:
            return render_template('form.html', message="Positive😊😊", score=score)
        elif score["compound"] <= -0.05:
            return render_template('form.html', message="Negative😞😞", score=score)
        else:
            return render_template('form.html', message="Neutral😐😐", score=score)
    
    return render_template('form.html')

if __name__ == "_main_":
    app.run(debug=True)